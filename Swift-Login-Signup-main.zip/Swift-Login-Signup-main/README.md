# Swift | Beautiful Login and Signup Page UI/UX Design Compatible on all devices
Beautiful Login and Signup Page UI/UX Design Compatible on all devices

This repository is a part of the 100-day design in Swift Using Storyboard.


Designed by Yasir Ahmad Noori (<a href="https://www.instagram.com/yasrinoori/">@yasrinoori</a>) on Instagram


# ScreenShot

Compatible on all devices

<p>
<a target="_blank" href="https://github.com/AbdullahALotaibi1/Swift-Login-Signup/blob/main/Screenshots/1.png"><img src="https://github.com/AbdullahALotaibi1/Swift-Login-Signup/blob/main/Screenshots/4.png"  style="max-width:100%;"></a>
</p>

Welcome Page
<p>
<a target="_blank" href="https://github.com/AbdullahALotaibi1/Swift-Login-Signup/blob/main/Screenshots/1.png"><img src="https://github.com/AbdullahALotaibi1/Swift-Login-Signup/blob/main/Screenshots/1.png" height="500em" style="max-width:100%;"></a>
</p>

Login Page
<p>
<a target="_blank" href="https://github.com/AbdullahALotaibi1/Swift-Login-Signup/blob/main/Screenshots/1.png"><img src="https://github.com/AbdullahALotaibi1/Swift-Login-Signup/blob/main/Screenshots/2.png" height="500em" style="max-width:100%;"></a>
</p>

Signup Page
<p>
<a target="_blank" href="https://github.com/AbdullahALotaibi1/Swift-Login-Signup/blob/main/Screenshots/1.png"><img src="https://github.com/AbdullahALotaibi1/Swift-Login-Signup/blob/main/Screenshots/3.png" height="500em" style="max-width:100%;"></a>

</p>
